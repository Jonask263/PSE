package de.unistuttgart.iste.sqa.pse.sheet10.homework.warehouse;

/**
 * A identifier to identify an individual piece of stationery.
 */
public final class Identifier {}

package de.unistuttgart.iste.sqa.pse.sheet10.presence.scopes;

/**
 * This class contains the {@code main} method with which the game can be started.
 */
public class WeAreAllPauleHereHamsterGameApp {
	public static void main(String[] args) {
		final WeAreAllPauleHereHamsterGame game = new WeAreAllPauleHereHamsterGame();
		game.doRun();
	}
}

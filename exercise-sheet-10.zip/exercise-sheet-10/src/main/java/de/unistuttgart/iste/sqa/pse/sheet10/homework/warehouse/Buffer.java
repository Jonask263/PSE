package de.unistuttgart.iste.sqa.pse.sheet10.homework.warehouse;

import de.unistuttgart.iste.sqa.pse.sheet10.homework.warehouse.items.StationeryItem;

import java.util.*;

/**
 * Represents a buffer for temporary storage of items.
 *
 * @author Jonas Kaluza (3740969)
 * @author Taha Darende (3724493)
 */
public final class Buffer {

	// TODO add data structure for exercise 1f here.
	final List<StationeryItem> buffer;

	// TODO add documentation here

	/**
	 * Creates a new Buffer
	 * ensures items3 is initialized as new Linkedlist
	 */
	public Buffer() {
		buffer = new LinkedList<StationeryItem>();
		// TODO initialize data structure for exercise 1f here.
	}

	// TODO add documentation here

	/**
	 * Puts an item in the buffer
	 * requires Buffer to be initialized
	 * ensures Item has been added to buffer
	 * @param stationeryItem The item to be buffered
	 * @throws NullPointerException, if buffer is not initialized
	 */
	public void bufferItem(final StationeryItem stationeryItem) {
		if(buffer == null){
			throw new NullPointerException("buffer is not initialized");
		}
		buffer.add(stationeryItem);
		// TODO implement exercise 1g here.
	}

	// TODO add documentation here

	/**
	 * removes first item from the Buffer to be released
	 * requires Buffer to be initialized + at least 1 item in the buffer
	 * ensures first item has been removed from buffer
	 * @return item The item that has been released
	 * @throws RuntimeException, if there is no item in the buffer
	 */
	public StationeryItem releaseItem() {
		if(buffer.isEmpty()){
			throw new RuntimeException("buffer is empty");
		}
		StationeryItem item = buffer.get(0);
		buffer.remove(0);
		// TODO implement exercise 1g here.
		return item; // TODO delete this line if necessary.
	}

	// TODO add documentation here

	/**
	 * Checks whether the buffer is empty
	 * requires Buffer to be initialized
	 * ensures nothing changed
	 * @return true If buffer is empty, false If there is at least 1 item
	 */
	public /*@ pure @*/ boolean isEmpty() {
		if(buffer == null){
			throw new RuntimeException("buffer is not initialized");
		}
		if(buffer.isEmpty()){
			return true;
		} else {
			return false; // TODO delete this line if necessary.
		}
		// TODO implement exercise 1g here.
	}
}
